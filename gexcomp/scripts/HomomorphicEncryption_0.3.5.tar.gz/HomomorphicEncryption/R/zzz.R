.onAttach = function(libname, pkgname) {
  packageStartupMessage('NOTE: this is an academic research implementation of homomorphic encryption schemes and no warranty of correctness or security is provided.\n\nFor citation information, type citation("HomomorphicEncryption").\n')
}
